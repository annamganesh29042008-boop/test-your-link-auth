// firebase.js — include AFTER firebase-app-compat.js and firebase-auth-compat.js
(function(){
  const firebaseConfig = {
    apiKey: "AIzaSyBuLni9j6YLiPXCvuEy2jUqxtISQ04dFCk",
    authDomain: "check-your-link.firebaseapp.com",
    projectId: "check-your-link",
    storageBucket: "check-your-link.firebasestorage.app",
    messagingSenderId: "714892957171",
    appId: "1:714892957171:web:ff9c02ee05b69d166f6e86",
    measurementId: "G-EM0C5YRY0P"
  };
  firebase.initializeApp(firebaseConfig);
  window.firebaseAuth = firebase.auth();
  console.log('Firebase initialized');
})();